.. Django Hackathon Starter documentation master file, created by
   sphinx-quickstart on Sun Apr 12 22:33:44 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Django Hackathon Starter's documentation!
====================================================

Contents:

.. toctree::
   :maxdepth: 2

Github
======
.. automodule:: github
	:members:

Instagram
=========
.. automodule:: instagram
	:members:

Steam
=====
.. automodule:: steam
	:members:

Tumblr
======
.. automodule:: tumblr
	:members:

Twilio
======
.. automodule:: twilioapi
	:members:

Twitter
=======
.. automodule:: twitter
	:members:

Scraper
=======
.. automodule:: scraper
	:members:

New York Times
==============
.. automodule:: nytimes
	:members:

Instagram
=========
.. automodule:: instagram
	:members:




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

